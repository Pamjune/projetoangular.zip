# Projeto Client com FrontEnd Angular

## Instruções do Projeto
* Para criar o projeto: ng new `nome_do_projeto`
* Para rodar o projeto: `ng s -o`
* Para parar o projeto: `CTRL + C`

### Instalação de Bibliotecas
* Bootstrap: `npm i bootstrap`
* Anotar no angular.json
* Fontawesome: `npm i @fortawesome/fontawesome-free`
* Anotar no angular.json
* Animate css: `npm install animate.css --save`
* Anotar no angular.json

### Sites
* https://randomuser.me/photos
* https://animate.style/
* https://getbootstrap.com/
* https://fontawesome.com/icons

### Criar componentes
* ng g c home
* ng g c user


